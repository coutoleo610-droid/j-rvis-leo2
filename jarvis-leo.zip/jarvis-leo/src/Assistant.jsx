import { useWakeWord } from "./hooks/useWakeWord";

export default function Assistant() {
  const handleCommand = (command) => {
    if (command.includes("hora")) {
      const hora = new Date().toLocaleTimeString();
      speak(`Agora são ${hora}`);
    } else if (command.includes("seu nome")) {
      speak("Eu sou Jarvis, seu assistente pessoal.");
    } else {
      speak("Comando não reconhecido.");
    }
  };

  useWakeWord(handleCommand);

  return (
    <div style={container}>
      <h1 style={title}>JARVIS</h1>
      <p style={{ color: "#00f0ff" }}>Diga: "Jarvis"</p>
    </div>
  );
}

function speak(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR";
  speechSynthesis.speak(utterance);
}

const container = {
  height: "100vh",
  background: "black",
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  alignItems: "center",
  fontFamily: "Arial"
};

const title = {
  color: "#00f0ff",
  fontSize: "60px",
  letterSpacing: "10px"
};
