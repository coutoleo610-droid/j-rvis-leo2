import { useEffect, useRef } from "react";

export function useWakeWord(onCommand) {
  const listeningForCommand = useRef(false);

  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Seu navegador não suporta reconhecimento de voz");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "pt-BR";
    recognition.continuous = true;
    recognition.interimResults = false;

    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript.toLowerCase();

      if (!listeningForCommand.current) {
        if (text.includes("jarvis")) {
          listeningForCommand.current = true;
          speak("Sim, Leo?");
        }
      } else {
        listeningForCommand.current = false;
        onCommand(text);
      }
    };

    recognition.onend = () => recognition.start();
    recognition.start();

    return () => recognition.stop();
  }, [onCommand]);
}

function speak(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR";
  speechSynthesis.speak(utterance);
}
